<?php
/**
 * Created by PhpStorm.
 * User: Zhanhao
 * Date: 2016/4/9
 * Time: 14:14
 */

$css = [
    'custom'         => '/oneoaas/assets/css/custom.css',
    'oneoaas'        => '/oneoaas/assets/css/oneoaas.css',
    'datetimepicker' => '/oneoaas/assets/css/jquery.datetimepicker.css',
    'ztree'          => '/oneoaas/assets/css/zTreeStyle/zTreeStyle.css',
    'pagination'     => '/oneoaas/assets/css/simplePagination.css',
];